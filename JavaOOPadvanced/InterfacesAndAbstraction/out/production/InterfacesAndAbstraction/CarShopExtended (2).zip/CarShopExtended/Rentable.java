package CarShopExtended;

import CarShop.*;

/**
 * Created by 200sx on 3/18/2017.
 */
public interface Rentable extends Car {

    int getMinRentDay();
    double getPricePerDay();

}
