package CarShopExtended;

/**
 * Created by 200sx on 3/18/2017.
 */
public interface Car {
    int TIRES = 4;

    String getModel();
    String getColor();
    int getHorsePower();
}
