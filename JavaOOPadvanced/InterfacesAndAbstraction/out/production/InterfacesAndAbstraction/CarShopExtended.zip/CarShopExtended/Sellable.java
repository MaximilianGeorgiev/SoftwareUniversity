package CarShopExtended;

import CarShop.*;

/**
 * Created by 200sx on 3/18/2017.
 */
public interface Sellable extends Car{
    double getPrice();
}
