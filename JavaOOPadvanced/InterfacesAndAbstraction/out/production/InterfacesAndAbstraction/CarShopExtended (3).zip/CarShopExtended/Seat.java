package CarShopExtended;

import java.io.Serializable;

/**
 * Created by 200sx on 3/18/2017.
 */
public class Seat implements Serializable, Car, Sellable, Rentable {
    private String model;
    private String color;
    private int horsePower;
    private String countryProduced;
   private double price;

    public Seat(String model, String color, Integer horsePower, String countryProduced,  Double price) {
        this.model = model;
        this.color = color;
        this.horsePower = horsePower;
        this.countryProduced = countryProduced;
        this.price = price;
    }

    @Override
    public String getModel() {
        return this.model;
    }

    @Override
    public String getColor() {
        return this.color;
    }

    @Override
    public int getHorsePower() {
        return this.horsePower;
    }

    public int getTires() {
        return Car.TIRES;
    }

    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append("This is ").append(this.getModel()).append(" produced in ").append(this.getCountryProduced())
                .append(" and have ").append(this.getTires()).append(" tires");

        return sb.toString();
    }

    private String getCountryProduced() {
        return countryProduced;
    }

    @Override
    public int getMinRentDay() {
        return 0;
    }

    @Override
    public double getPricePerDay() {
        return 0;
    }

    @Override
    public double getPrice() {
        return 0;
    }
}
