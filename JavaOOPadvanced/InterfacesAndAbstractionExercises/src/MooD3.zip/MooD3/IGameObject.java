package MooD3;

public interface IGameObject {

    String getUserName();

    String getHashedPassword();

    int getLevel();

    double getSpecialPoints();
}